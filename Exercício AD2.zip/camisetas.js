/*
JAVASCRIPT DE CAMISETAS

Declaração das VARIAVEIS
*/

function imgCamisaDudalinaBranca() {
	document.getElementById("trocarImg").src="Imagens/CamBasDudalina_Branca.jpg"; // Troca a imagem da camisa
	document.getElementById("caixa").innerHTML="Tamanhos P/M/G/GG"; // Troca a mensagem Tamanho 
	document.getElementById("precoNovo").innerHTML="Preço - R$ 100,00"; // Troca a mensagem Preço 
}
function imgCamisaHeringAzul() {
	document.getElementById("trocarImg").src="Imagens/CamBasHering_Azul.jpg";
	document.getElementById("caixa").innerHTML="Tamanhos P/M/G/XG/XXG"; // Troca a mensagem Tamanho 
	document.getElementById("precoNovo").innerHTML="Preço - R$ 70,00"; // Troca a mensagem Preço
}
function imgCamisaHeringChumbo() {
	document.getElementById("trocarImg").src="Imagens/CamBasHering_Chumbo.jpg";
	document.getElementById("caixa").innerHTML="Tamanhos P/M/G/XG/XXG"; // Troca a mensagem Tamanho 
	document.getElementById("precoNovo").innerHTML="Preço - R$ 70,00"; // Troca a mensagem Preço
}
function imgCamisaHeringVerde() {
	document.getElementById("trocarImg").src="Imagens/CamBasHering_Verde.jpg";
	document.getElementById("caixa").innerHTML="Tamanhos P/M/G/XG/XXG"; // Troca a mensagem Tamanho 
	document.getElementById("precoNovo").innerHTML="Preço - R$ 70,00"; // Troca a mensagem Preço
}
function imgCamisaMarfinnoAzul() {
	document.getElementById("trocarImg").src="Imagens/CamBasMarfinno_azul.jpg";
	document.getElementById("caixa").innerHTML="Tamanhos P/M/G/GG"; // Troca a mensagem Tamanho 
	document.getElementById("precoNovo").innerHTML="Preço - R$ 30,00"; // Troca a mensagem Preço
}
function imgCamisaMarfinnoBranca() {
	document.getElementById("trocarImg").src="Imagens/CamBasMarfinno_branca.jpg";
	document.getElementById("caixa").innerHTML="Tamanhos P/M/G/GG"; // Troca a mensagem Tamanho 
	document.getElementById("precoNovo").innerHTML="Preço - R$ 30,00"; // Troca a mensagem Preço
}